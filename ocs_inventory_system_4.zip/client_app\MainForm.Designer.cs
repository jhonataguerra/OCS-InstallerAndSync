using System.Drawing;
using System.Windows.Forms;

namespace OCSCadastroApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel panelHeader;
        private Label lblHeaderTitle;
        private Label lblHeaderSubtitle;

        private GroupBox grpUsuario;
        private Label lblNome;
        private TextBox txtNome;
        private Label lblPatrimonio;
        private TextBox txtPatrimonio;
        private Label lblSetor;
        private TextBox txtSetor;

        private GroupBox grpSistema;
        private Label lblSysHostname;
        private Label lblSysUsuario;
        private Label lblSysSerial;
        private Label lblSysSO;

        private Panel panelAviso;
        private Label lblAvisoIcon;
        private Label lblAvisoPrazo;

        private Button btnEnviar;
        private Button btnFechar;
        private Label lblStatus;
        private Timer timerBloqueio;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.panelHeader = new Panel();
            this.lblHeaderTitle = new Label();
            this.lblHeaderSubtitle = new Label();

            this.grpUsuario = new GroupBox();
            this.lblNome = new Label();
            this.txtNome = new TextBox();
            this.lblPatrimonio = new Label();
            this.txtPatrimonio = new TextBox();
            this.lblSetor = new Label();
            this.txtSetor = new TextBox();

            this.grpSistema = new GroupBox();
            this.lblSysHostname = new Label();
            this.lblSysUsuario = new Label();
            this.lblSysSerial = new Label();
            this.lblSysSO = new Label();

            this.panelAviso = new Panel();
            this.lblAvisoIcon = new Label();
            this.lblAvisoPrazo = new Label();

            this.btnEnviar = new Button();
            this.btnFechar = new Button();
            this.lblStatus = new Label();
            this.timerBloqueio = new Timer(this.components);

            this.panelHeader.SuspendLayout();
            this.grpUsuario.SuspendLayout();
            this.grpSistema.SuspendLayout();
            this.panelAviso.SuspendLayout();
            this.SuspendLayout();

            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = Color.FromArgb(15, 23, 42); // Modern Slate 900
            this.panelHeader.Controls.Add(this.lblHeaderSubtitle);
            this.panelHeader.Controls.Add(this.lblHeaderTitle);
            this.panelHeader.Dock = DockStyle.Top;
            this.panelHeader.Location = new Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new Size(520, 72);
            this.panelHeader.TabIndex = 0;

            // 
            // lblHeaderTitle
            // 
            this.lblHeaderTitle.AutoSize = true;
            this.lblHeaderTitle.Font = new Font("Segoe UI", 13F, FontStyle.Bold, GraphicsUnit.Point);
            this.lblHeaderTitle.ForeColor = Color.White;
            this.lblHeaderTitle.Location = new Point(20, 14);
            this.lblHeaderTitle.Name = "lblHeaderTitle";
            this.lblHeaderTitle.Size = new Size(330, 25);
            this.lblHeaderTitle.Text = "Cadastro de Patrimônio & Identificação";

            // 
            // lblHeaderSubtitle
            // 
            this.lblHeaderSubtitle.AutoSize = true;
            this.lblHeaderSubtitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular, GraphicsUnit.Point);
            this.lblHeaderSubtitle.ForeColor = Color.FromArgb(148, 163, 184); // Slate 400
            this.lblHeaderSubtitle.Location = new Point(22, 42);
            this.lblHeaderSubtitle.Name = "lblHeaderSubtitle";
            this.lblHeaderSubtitle.Size = new Size(420, 15);
            this.lblHeaderSubtitle.Text = "Inventário Corporativo de Equipamentos — OCS Inventory NG";

            // 
            // grpUsuario
            // 
            this.grpUsuario.BackColor = Color.Transparent;
            this.grpUsuario.Controls.Add(this.txtSetor);
            this.grpUsuario.Controls.Add(this.lblSetor);
            this.grpUsuario.Controls.Add(this.txtPatrimonio);
            this.grpUsuario.Controls.Add(this.lblPatrimonio);
            this.grpUsuario.Controls.Add(this.txtNome);
            this.grpUsuario.Controls.Add(this.lblNome);
            this.grpUsuario.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.grpUsuario.ForeColor = Color.FromArgb(30, 41, 59); // Slate 800
            this.grpUsuario.Location = new Point(18, 82);
            this.grpUsuario.Name = "grpUsuario";
            this.grpUsuario.Size = new Size(484, 186);
            this.grpUsuario.TabIndex = 1;
            this.grpUsuario.TabStop = false;
            this.grpUsuario.Text = " Dados do Responsável ";

            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new Font("Segoe UI", 8.75F);
            this.lblNome.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblNome.Location = new Point(16, 25);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new Size(128, 15);
            this.lblNome.Text = "Nome do Responsável:";

            // 
            // txtNome
            // 
            this.txtNome.BorderStyle = BorderStyle.FixedSingle;
            this.txtNome.Font = new Font("Segoe UI", 9.5F);
            this.txtNome.Location = new Point(19, 44);
            this.txtNome.MaxLength = 150;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new Size(446, 24);
            this.txtNome.TabIndex = 2;
            this.txtNome.KeyPress += new KeyPressEventHandler(this.TxtNome_KeyPress);
            this.txtNome.TextChanged += new System.EventHandler(this.TxtNome_TextChanged);

            // 
            // lblPatrimonio
            // 
            this.lblPatrimonio.AutoSize = true;
            this.lblPatrimonio.Font = new Font("Segoe UI", 8.75F);
            this.lblPatrimonio.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblPatrimonio.Location = new Point(16, 75);
            this.lblPatrimonio.Name = "lblPatrimonio";
            this.lblPatrimonio.Size = new Size(106, 15);
            this.lblPatrimonio.Text = "Nº de Patrimônio:";

            // 
            // txtPatrimonio
            // 
            this.txtPatrimonio.BorderStyle = BorderStyle.FixedSingle;
            this.txtPatrimonio.Font = new Font("Segoe UI", 9.5F);
            this.txtPatrimonio.Location = new Point(19, 94);
            this.txtPatrimonio.MaxLength = 50;
            this.txtPatrimonio.Name = "txtPatrimonio";
            this.txtPatrimonio.Size = new Size(446, 24);
            this.txtPatrimonio.TabIndex = 3;
            this.txtPatrimonio.KeyPress += new KeyPressEventHandler(this.TxtPatrimonio_KeyPress);
            this.txtPatrimonio.TextChanged += new System.EventHandler(this.TxtPatrimonio_TextChanged);

            // 
            // lblSetor
            // 
            this.lblSetor.AutoSize = true;
            this.lblSetor.Font = new Font("Segoe UI", 8.75F);
            this.lblSetor.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblSetor.Location = new Point(16, 125);
            this.lblSetor.Name = "lblSetor";
            this.lblSetor.Size = new Size(82, 15);
            this.lblSetor.Text = "Setor / Local:";

            // 
            // txtSetor
            // 
            this.txtSetor.BorderStyle = BorderStyle.FixedSingle;
            this.txtSetor.Font = new Font("Segoe UI", 9.5F);
            this.txtSetor.Location = new Point(19, 144);
            this.txtSetor.MaxLength = 100;
            this.txtSetor.Name = "txtSetor";
            this.txtSetor.Size = new Size(446, 24);
            this.txtSetor.TabIndex = 4;

            // 
            // grpSistema
            // 
            this.grpSistema.BackColor = Color.Transparent;
            this.grpSistema.Controls.Add(this.lblSysSO);
            this.grpSistema.Controls.Add(this.lblSysSerial);
            this.grpSistema.Controls.Add(this.lblSysUsuario);
            this.grpSistema.Controls.Add(this.lblSysHostname);
            this.grpSistema.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold);
            this.grpSistema.ForeColor = Color.FromArgb(71, 85, 105);
            this.grpSistema.Location = new Point(18, 276);
            this.grpSistema.Name = "grpSistema";
            this.grpSistema.Size = new Size(484, 82);
            this.grpSistema.TabIndex = 5;
            this.grpSistema.TabStop = false;
            this.grpSistema.Text = " Informações do Equipamento ";

            // 
            // lblSysHostname
            // 
            this.lblSysHostname.AutoSize = true;
            this.lblSysHostname.Font = new Font("Segoe UI", 8.25F);
            this.lblSysHostname.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblSysHostname.Location = new Point(16, 22);
            this.lblSysHostname.Name = "lblSysHostname";
            this.lblSysHostname.Size = new Size(62, 13);
            this.lblSysHostname.Text = "Hostname: ";

            // 
            // lblSysUsuario
            // 
            this.lblSysUsuario.AutoSize = true;
            this.lblSysUsuario.Font = new Font("Segoe UI", 8.25F);
            this.lblSysUsuario.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblSysUsuario.Location = new Point(236, 22);
            this.lblSysUsuario.Name = "lblSysUsuario";
            this.lblSysUsuario.Size = new Size(76, 13);
            this.lblSysUsuario.Text = "Usuário Atual: ";

            // 
            // lblSysSerial
            // 
            this.lblSysSerial.AutoSize = true;
            this.lblSysSerial.Font = new Font("Segoe UI", 8.25F);
            this.lblSysSerial.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblSysSerial.Location = new Point(16, 46);
            this.lblSysSerial.Name = "lblSysSerial";
            this.lblSysSerial.Size = new Size(68, 13);
            this.lblSysSerial.Text = "Serial BIOS: ";

            // 
            // lblSysSO
            // 
            this.lblSysSO.AutoSize = true;
            this.lblSysSO.Font = new Font("Segoe UI", 8.25F);
            this.lblSysSO.ForeColor = Color.FromArgb(51, 65, 85);
            this.lblSysSO.Location = new Point(236, 46);
            this.lblSysSO.Name = "lblSysSO";
            this.lblSysSO.Size = new Size(51, 13);
            this.lblSysSO.Text = "Sistema: ";

            // 
            // panelAviso
            // 
            this.panelAviso.BackColor = Color.FromArgb(254, 243, 199);
            this.panelAviso.BorderStyle = BorderStyle.FixedSingle;
            this.panelAviso.Controls.Add(this.lblAvisoIcon);
            this.panelAviso.Controls.Add(this.lblAvisoPrazo);
            this.panelAviso.Location = new Point(18, 368);
            this.panelAviso.Name = "panelAviso";
            this.panelAviso.Size = new Size(484, 52);
            this.panelAviso.TabIndex = 6;

            // 
            // lblAvisoIcon
            // 
            this.lblAvisoIcon.AutoSize = true;
            this.lblAvisoIcon.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblAvisoIcon.ForeColor = Color.FromArgb(180, 83, 9);
            this.lblAvisoIcon.Location = new Point(9, 13);
            this.lblAvisoIcon.Name = "lblAvisoIcon";
            this.lblAvisoIcon.Size = new Size(26, 21);
            this.lblAvisoIcon.Text = "ℹ";

            // 
            // lblAvisoPrazo
            // 
            this.lblAvisoPrazo.Font = new Font("Segoe UI", 8.25F);
            this.lblAvisoPrazo.ForeColor = Color.FromArgb(120, 53, 15);
            this.lblAvisoPrazo.Location = new Point(38, 4);
            this.lblAvisoPrazo.Name = "lblAvisoPrazo";
            this.lblAvisoPrazo.Size = new Size(438, 42);
            this.lblAvisoPrazo.Text = "Preenchimento necessário para o inventário corporativo.\nApós preenchido e enviado, esta janela não será mais exibida.";
            this.lblAvisoPrazo.TextAlign = ContentAlignment.MiddleLeft;

            // 
            // btnEnviar
            // 
            this.btnEnviar.BackColor = Color.FromArgb(22, 163, 74); // Emerald 600
            this.btnEnviar.Cursor = Cursors.Hand;
            this.btnEnviar.FlatAppearance.BorderColor = Color.FromArgb(21, 128, 61);
            this.btnEnviar.FlatStyle = FlatStyle.Flat;
            this.btnEnviar.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            this.btnEnviar.ForeColor = Color.White;
            this.btnEnviar.Location = new Point(262, 428);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new Size(240, 36);
            this.btnEnviar.TabIndex = 7;
            this.btnEnviar.Text = "Gravar e Concluir";
            this.btnEnviar.UseVisualStyleBackColor = false;
            this.btnEnviar.Click += new System.EventHandler(this.BtnEnviar_Click);

            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = Color.FromArgb(226, 232, 240); // Slate 200
            this.btnFechar.Cursor = Cursors.Default;
            this.btnFechar.Enabled = false;
            this.btnFechar.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            this.btnFechar.FlatStyle = FlatStyle.Flat;
            this.btnFechar.Font = new Font("Segoe UI", 8.5F);
            this.btnFechar.ForeColor = Color.FromArgb(100, 116, 139);
            this.btnFechar.Location = new Point(18, 428);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new Size(234, 36);
            this.btnFechar.TabIndex = 8;
            this.btnFechar.Text = "Fechar (10s)";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.BtnFechar_Click);

            // 
            // lblStatus
            // 
            this.lblStatus.Font = new Font("Segoe UI", 8F, FontStyle.Italic);
            this.lblStatus.ForeColor = Color.FromArgb(100, 116, 139);
            this.lblStatus.Location = new Point(18, 470);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new Size(484, 18);
            this.lblStatus.TextAlign = ContentAlignment.MiddleCenter;

            // 
            // timerBloqueio
            // 
            this.timerBloqueio.Interval = 1000;
            this.timerBloqueio.Tick += new System.EventHandler(this.TimerBloqueio_Tick);

            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(248, 250, 252); // Slate 50
            this.ClientSize = new Size(520, 496);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.panelAviso);
            this.Controls.Add(this.grpSistema);
            this.Controls.Add(this.grpUsuario);
            this.Controls.Add(this.panelHeader);
            this.Font = new Font("Segoe UI", 9F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Identificação de Patrimônio — OCS Inventory";
            this.FormClosing += new FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.grpUsuario.ResumeLayout(false);
            this.grpUsuario.PerformLayout();
            this.grpSistema.ResumeLayout(false);
            this.grpSistema.PerformLayout();
            this.panelAviso.ResumeLayout(false);
            this.panelAviso.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}
